<template>
<div>

  <section class="hero">
    <header>
      <img src="../assets/logo.jpg" alt="">
      <ul>
        <li>Agents</li>
        <li>Login</li>
        <li>Signup</li>
      </ul>
    </header>
      <h1>Relex,Finding An Agent Just Got Easier</h1>
      <h2>Receive proposals from best agents for free</h2>
      <form action=""><input type="text" placeholder="Enter a suburb">
      <input type="button" value="search"></form>
  </section>
  <section class="numbers">
    <ul>
      <li class="number">
        <h2>20,000</h2>
        <h3>Agents</h3>
      </li>
      <li class="number">
        <h2>1,723,000</h2>
        <h3>Transactions</h3>
      </li>
      <li class="number">
        <h2>17.444</h2>
        <h3>Agencies</h3>
      </li>
      <li class="number">
        <h2>10.200</h2>
        <h3>suburbs</h3>
      </li>
    </ul>
  </section>

  <section class="how-it-works">
    <h2>How it works</h2>
    <ul>
      <li>
        <div class="detail">
          <span class="number">1</span>
          

          <i class="icon-newspaper"></i>
      
          <h3>Compare</h3>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Veniam amet voluptatum incidunt suscipit facere, labore quidem tempora voluptas eligendi consequuntur voluptatem, sed modi maiores dolor accusantium ut neque? Possimus, consequuntur.</p>
        </div>
      </li>
      <li>
        <div class="detail">
          <span class="number">2</span>
          <i class="icon-pencil"></i>
          <h3>Receive Proposals</h3>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cum autem voluptates molestiae at eos? Possimus, voluptatibus! Temporibus voluptatum iste nam, soluta ducimus accusantium mollitia consectetur veritatis ipsam. Ducimus, eum veritatis.</p>
        </div>
      </li>
      <li>
        <div class="detail">
          <span class="number">3</span>
          <i class="icon-users"></i>
          <h3>Sell with the Best</h3>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nisi facere minus quo voluptatum accusamus aspernatur fugiat sequi quisquam reiciendis tempore tenetur possimus debitis corporis dolore reprehenderit vero, quod, odio doloribus?</p>
        </div>
      </li>
    </ul>
  </section>
  
  <section class="why-choose-us">
    <h2>why choose us?</h2>
      <div class="content">
        <div class="box">
          <div class="icon">
            <i class="icon-checkmark"></i>
          </div>
          <div class="iright">
            <h3 class="h3">Quick</h3>
            <p class="p">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Provident temporibus, deleniti esse! Amet esse, fugit facere, nesciunt nemo  </p>
          </div>
         
      </div>
      <div class="box">
          <div class="icon">
            <i class="icon-price-tag"></i>
          </div>
          <div class="iright">
            <h3 class="h3">Free</h3>
            <p class="p">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Provident temporibus, deleniti esse! Amet esse, fugit facere, nesciunt nemo  </p>
          </div>
         
      </div>
      <div class="box">
          <div class="icon">
            <i class="icon-loop2"></i>
          </div>
          <div class="iright">
            <h3 class="h3">Easy</h3>
            <p  class="p">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Provident temporibus, deleniti esse! Amet esse, fugit facere, nesciunt nemo  </p>
          </div>
         
      </div>
      <div class="box">
          <div class="icon">
            <i class="icon-user"></i>
          </div>
          <div class="iright">
            <h3 class="h3">independent</h3>
            <p class="p">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Provident temporibus, deleniti esse! Amet esse, fugit facere, nesciunt nemo  </p>
          </div>
         
      </div>
      <div class="box">
          <div class="icon">
            <i class="icon-file-text"></i>
          </div>
          <div class="iright">
            <h3 class="h3">Comprehensive</h3>
            <p class="p">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Provident temporibus, deleniti esse! Amet esse, fugit facere, nesciunt nemo  </p>
          </div>
         
      </div>
      <div class="box">
          <div class="icon">
            <i class="icon-point-right"></i>
          </div>
          <div class="iright">
            <h3 class="h3">Awesome</h3>
            <p class="p">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Provident temporibus, deleniti esse! Amet esse, fugit facere, nesciunt nemo  </p>
          </div>
         
      </div>
      
    </div>
  </section>

  <section class="commentarea">
    <div class="buttonarea">    
      <input type="button" class="button1" value="Testmonials">
      <input type="button" class="button2" value="Recent Feedbacks">
    </div>
    <div class="comment">
      <h2>“</h2>
      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Facilis maxime aspernatur sit nesciunt deleniti. Molestiae alias voluptatem quisquam incidunt, quam! Voluptates molestias </p>
    </div>
    <div class="auth">
       <p>John Mayer</p>
       <p class="job">Halcyon,CEO</p>
    </div>
    <div class="pic">
      <ul>
        <li><div><img src="../assets/peo1.jpg" alt=""></div></li>
        <li><div class=""><img class="special specialout" src="../assets/peo2.jpg" alt=""></div></li>
        <li><div><img src="../assets/peo3.jpg" alt=""></div></li>
      </ul>
    </div>
  </section>

  <section >
    <div class="form-bottom">
    <div class="find">
      <p>Find an Agent</p>
      <form class="form1"action=""><input type="text" placeholder="Enter a suburb">
    <input type="button" value="search"></form>
    </div>
      
    </div>
  </section>
  <section >
    <div class="footer">
      <ul>
        <li><a href="#">Blog</a></li>
        <li><a href="#">contact Us</a></li>
        <li><a href="#">About US</a></li>
        <li><a href="#">FAQs</a></li>
        <li><a href="#">Privacy</a></li>
        <li><a href="#">Disclaimer</a></li>
      </ul>
      <div class="icon1">
        <i class="icon-pencil"></i>
        <i class="icon-point-right"></i>
      </div>
    </div>
  </section>
</div>
</template>

<script>
export default {
  name: 'HelloWorld',
  data () {
    return {
      msg: 'Welcome to Your Vue.js App'
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">




a {
  color: #9799ad;
  text-decoration: none;
}


*{
  margin: 0px;
  padding: 0px;

}
body{
  font-size:62.5%;
  text-align:center;
}

@mixin clearfix(){
  clear:both;
}
@mixin border-radius($radius:5px){
border-radius:$radius;
}

$bg-color:#fff;
$text-color:#4f4f4f;
$secondy-text-color:#d9dada;
$highlight-text-color:white;
$button-color:#6cdcac;
$border-color:#ccc;
.hero{
    max-width: 100em;
    margin:0 auto;

    background:url(../assets/bg.jpg);
    background-size:cover;
    color:$highlight-text-color;
     
    header{

          img{
            width:8em;
            height:2em;
            float:left;
            margin-left:5em;
            margin-top:2em;
          }
          ul{
            float:right;
            list-style-type: none;
            margin-right:5em;
            margin-top:0.6em;
            li{
              float:left;
              margin:1em .5em;
              padding:.5em 1em;
              border:1px solid transparent;
              border-radius:2px;
              &:last-child{
                border:1px solid $highlight-text-color;
              }

            }
          }
        @include clearfix();
      }
      h1{
        font-size: 3.3em;
        padding:5em 0 .5em 0;
        font-weight:bold;
        position: relative;


        

      }
      h2{
        font-size:2em;
        color:$secondy-text-color;
      }


      form{
        padding:2em 0 8em 0;
        input[type='text']{
          padding:1em;
          border:0;
          width:18em;
          border-radius:2px 0 0 2px;
          background:$bg-color;
          opacity:.3;
        }
        input[type='button']{
          color:$highlight-text-color;
          padding:1em;
          border:0;
          width:6em;
          border-radius:0 2px 2px 0;
          background-color:$button-color;
          text-transform:uppercase;

        }
      }
    }


.numbers{
  width:80%;
  margin:0 auto;
  background-color:#00f;
  ul{
    position: relative;
    top:-4em;
    
    list-style-type: none;
    li{
      float:left;
      width:25%;
      box-sizing:border-box;
      border-top:1px solid $secondy-text-color;
      border-bottom:1px solid $secondy-text-color;
      border-left:1px solid $secondy-text-color;
      background-color:white;
      &:last-child{
        border-right:1px solid $secondy-text-color;
      }

      h2{
        font-size:2em;
        padding:1em 0;
      }
      h3{
        padding:0 0 2em 0;
      }
    }
    @include clearfix;
  }
}

.how-it-works{
  h2{
    font-size:2em;
    text-transform:uppercase;
    padding-top:6em;
    padding-bottom:1em;
    &:after{
      display:block;
      content:"";
      background-color:$border-color;
      width:2em;
      height:.1em;
      margin:.4em auto;
    }
  }
  ul{
    list-style-type: none;

    li{
      float:left;
      width:33.33%;
      &:before{
        display:block;
        content:"";
        background-color:$border-color;
        width:88%;
        height:1px;
        position: relative;
        top:4em;
        left:50%;
        margin:0 2em;
      }
      &:last-child:before{
        display:none;
      }
      .detail{
        i{
          display:block;
          font-size:3.6em;
          padding-bottom:0.2em;
        }

        .icon-newspaper{
          color:#eca95a;

        }
        .icon-pencil{
          color:#ac9cd2;
        }
        .icon-users{
          color:#4d99cb;
        }
        .icon{
          width:30px;
          height:50px;
          margin:0 auto;
        }

        p{
          padding:1em 0;
        }


        .number{
          font-size:2em;
          color:$border-color;
          border:1px solid $border-color;
          width:1em;
          height:1em;
          display:block;
          margin:1em auto 1em auto;
          padding:.4em;
          @include border-radius(100%);
          background-color:$bg-color;
        }
        p{
          margin:0 auto;
          width:20em;

        }
      }

    }

  }
  padding-bottom:28em;
  border-bottom:1px solid $border-color;
}


.why-choose-us{

  h2{
    font-size:2em;
    text-transform:uppercase;
    padding-top:2em;
    margin:0;
    padding-bottom:1em;
    &:after{
      display:block;
      content:"";
      background-color:$border-color;
      width:2em;
      height:.1em;
      margin:.4em auto;
    }
  }
  .content{
    padding:0 3.75em;

    .box{
      width:49%;
      height:6.25em;
      
       overflow:hidden;
       padding:0.312em 0.375em 2.5em 0.375em;
       float:left;
      .icon{
        float:left;
        width:13%;
        height:7.785em;
        margin-left:4.375em;
        
        i{
          font-size:3em;
        }
        .icon-checkmark{
          color:#78bb9a;
        }
        .icon-price-tag{
          color:#00bbf9;
        }
        .icon-loop2{
          color:#eca95d;
        }
        .icon-user{
          color:#ad7ac1;
        }
        .icon-file-text{
          color:#de7f8e;
        }
        .icon-point-right{
          color:#e6864d;
        }

      }

      .iright{
        float:right;
        width:68.7%;
        margin-right:3.125em;

        .h3{
          text-align:left;
          padding:0.312em 0.312em;
        }
        .p{
          width:30em;
          padding-right:3.125em;
          
        }

      }
    }

    ul{
      list-style-type: none;
    }

  }
  padding-bottom:30em;
  border-bottom:0.063em solid $border-color;
}

.commentarea{
  width:90%;
  margin:6em auto;
  margin-bottom:0px;
  height:38em;
 
  .buttonarea{
    width:30%;
    height:4.8em;
    margin:0 auto;
    
    .button1{
      float:left;
     width:49%;
     height:3em;
     background-color:#5f687a;
     color:#fdfdff;
     font-weight:bold;
     text-align:center;
     font-size:1.6em;
     border:0;
    }
    .button2{
      float:left;
      width:49%;
      height:3.2em;
      border:1px solid #696c72;
      background-color:#fff; 
      font-weight:bold;
     text-align:center;
     font-size:1.5em;
     color:#696c72;  
    }
    @include clearfix;
  }

  .comment{
    width:100%;
    
    position: relative;

    text-align:center;
    h2{
      color:#696c72;
      font-size:3.75em;
      height:1em;
      margin-top:0.5em;
    }
    p{
      font-size:1.6em;

    }

  }
  .auth{
    margin-top:2em;
    p{
      font-size:1.6em;
      font-weight:bold;
    }
    .job{
      color:#a2a1a2;
    }
  }

  .pic{
    
    width:50%;
    margin :auto;
    margin-top:3em;
    ul{
      list-style-type: none;
      margin-left:8em;

    }
    li{
      float:left;
      margin-right:4em;
      .specialout{
        padding:5px;
      }


    }
    img{
      width:7;
      height:7em;
      
      @include border-radius(100%);
      

    }
    .special{
        
        border:1px solid #a2a1a2
      }
  }

}

.form-bottom{
  background:url(../assets/bg.jpg) no-repeat;
  width:100%;
  background-size:cover;
  height:15em;
  .find{
    width:90%;
    margin:auto;
    padding:4em;
    p{
      float:left;
      font-size:1.6em;
      font-weight:bold;
      padding-top:1.5em;
      margin-left:10em;
      color:white;


    }

  }
  .form1{
        padding:2em 0 8em 0;
        width:100em;
        margin-left:-20em;
        input[type='text']{
          padding:1em;
          border:0;
          width:45em;
          border-radius:2px 0 0 2px;
          background-color:white;
          font-weight:bold;
          opacity:1;
        }
        input[type='button']{
          color:$highlight-text-color;
          padding:1em;
          border:0;
          width:6em;
          border-radius:0 2px 2px 0;
          background-color:$button-color;
          text-transform:uppercase;

        }
      }
}

.footer{
  
  height:2.8em;
  padding:1.5em;

  ul{
    list-style-type: none;
    margin-left:10em;
  }
  li{
    float:left;
    margin-right:1em;
    font-size:1.6em;
    height:2em;
  }
  .icon1{
   
    height:3em;
    padding-top:0.5em;
    margin-right:15em;
    
    float:right;
    
    .icon-pencil{
      font-size:1.8em;
      margin-right:1em;
      color:#4e96d3;

    }
    .icon-point-right{
      font-size:1.6em;
      color:#4c71c4;
    }
  }

}
</style>
