import Vue from 'vue'
import Router from 'vue-router'
import MyDesign from '@/components/MyDesign'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'MyDesign',
      component: MyDesign
    }
  ]
})
