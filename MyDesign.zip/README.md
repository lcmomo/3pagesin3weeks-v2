# mydesign

> my third work

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build

# build for production and view the bundle analyzer report
npm run build --report
```

For a detailed explanation on how things work, check out the [guide](http://vuejs-templates.github.io/webpack/) and [docs for vue-loader](http://vuejs.github.io/vue-loader).


#该页面基于谷歌浏览器+1680宽度的屏幕进行编写，开发环境为 vuecli +npm +webpack，dist目录为经过webpack打包后生成的静态页面，index.html
为入口文件，用浏览器打开可看到页面效果
