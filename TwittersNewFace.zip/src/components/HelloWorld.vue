<template>
  <div class="hello">
    <header class="header">
      <nav>
        <ul>
          <li><a href="#" class="compose"><i class="icon-quill"></i></a></li>
          <li><a href="#" class="alert"><i class="icon-bell"></i></a></li>
          <li><a href="#" class="email"><i class="icon-envelop"></i></a></li>
          <li><a href="#" class="tag"><i class="icon-svg"></i></a></li>
        </ul>
        <div class="bird">
        <i class="icon-twitter"></i>
        </div>
        <div class="userimg"><img src="../assets/img/31.jpg" alt=""></div>
        <input type="text" value="   Search" ><i class="icon-search"></i>
        
      </nav>
    </header>
    <aside>
      <div class="profile">
        <div class="userimg1"><img src="../assets/img/31.jpg" class="img1" alt="">
        </div>
        <h3>kerem suer</h3>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tempore, libero. Sit voluptatibus voluptate minus, voluptatem aut! Quod dolorem, quis modi, illo nobis </p>
        <i class='icon-link'></i><span>www.kerem.com</span><br/>
        <input type="text" value="flollow">
      </div>
      <div class="gallery">
        <div class="imgwall">
          <div class="imgs"><img src="../assets/img/11.jpg" alt=""></div>
          <div class="imgs"><img src="../assets/img/21.jpg" alt=""></div>
          <div class="imgs"><img src="../assets/img/11.jpg" alt=""></div>
          <div class="imgs"><img src="../assets/img/21.jpg" alt=""></div>
          <div class="imgs"><img src="../assets/img/31.jpg" alt=""></div>
          <div class="imgs"><img src="../assets/img/21.jpg" alt=""></div>
          <div class="imgs"><img src="../assets/img/31.jpg" alt=""></div>
          <div class="imgs"><img src="../assets/img/32.jpg" alt=""></div>
          <div class="imgs"><img src="../assets/img/33.jpg" alt=""></div>
        </div>

      </div>
      <div class="activeties">
        <h3>ACTIVES</h3>
        <div class="linkto">
          <i class="icon-plus"></i>
          <span>Followed <a href="#">Eddle</a></span>
        </div>
        <div class="linkto">
          <i class="icon-redo2"></i>
          <span>Followed <a href="#">Alexander Tweet</a></span>
        </div>
        <div class="linkto">
          <i class="icon-loop2"></i>
          <span>Followed <a href="#">Erlc Tweet</a></span>
        </div>
        <div class="linkto">
          <i class="icon-loop2"></i>
          <span>Followed <a href="#">Erlc Tweet</a></span>
        </div>
        <div class="linkto">
          <i class="icon-star-full"></i>
          <span>Followed <a href="#">John Tweet</a></span>
        </div>


      </div>
    </aside>
    <section class="contents">
      <div class="box">
        <nav class="info">
          <ul>
            <li class="item">
              <h4>Tweets</h4>
              <p>200</p>
            </li>
            <li class="item">
              <h4>Photo/Videos</h4>
              <p>250</p>
            </li>
            <li class="item">
              <h4>Following</h4>
              <p>50</p></li>
            <li class="item">
              <h4>Followers</h4>
              <p>180</p>
            </li>
          </ul>
        </nav>
        <div class="articles">
          <article class="post">
            <img src="../assets/img/31.jpg" alt="" class="avator">
            <section class="content">
              <header>
                <span class="name">liliuchao</span>
                <span class="account">@llc</span>
                <span class="time">2m</span>
              </header>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nostrum quos, doloremque voluptatem optio fugit autem reiciendis temporibus. Molestias doloremque neque nulla sapiente enim</p>
              <footer>
                <nav>
                  <a href="#" class="icon-redo2"><i></i></a>
                  <a href="#" class="icon-star-full"><i></i></a>
                  <a href="#" class="icon-loop2"><i></i></a>
                  <a href="#" class="icon-flickr"><i></i></a>
                  <a href="#" class="icon-enlarge2"><i></i></a>
                </nav>
              </footer>
            </section>
          </article>
          <article class="post">
            <img src="../assets/img/2.jpg" alt="" class="avator">
            <section class="content">
              <header>
              <span class="icon-loop2"></span>
                <span class="name">AxelHerrmann</span>
                <span class="account">@axel_herrmann</span>
                <span class="time">1h</span>
              </header>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ut minima reiciendis molestiae officia dignissimos! </p>
              <footer>
                <nav>
                  <a href="#" class="icon-redo2"><i></i></a>
                  <a href="#" class="icon-star-full"><i></i></a>
                  <a href="#" class="icon-loop2"><i></i></a>
                  <a href="#" class="icon-flickr"><i></i></a>
                  <a href="#" class="icon-enlarge2"><i></i></a>
                </nav>
              </footer>
            </section>
          </article>
          <article class="post">
            <img src="../assets/img/31.jpg" alt="" class="avator">
            <section class="content">
              <header>
                <span class="name">liliuchao</span>
                <span class="account">@llc</span>
                <span class="time">2m</span>
              </header>
              <img src="../assets/img/4.jpg" alt="">
              <footer>
                <nav>
                  <a href="#" class="icon-redo2"><i></i></a>
                  <a href="#" class="icon-star-full"><i></i></a>
                  <a href="#" class="icon-loop2"><i></i></a>
                  <a href="#" class="icon-flickr"><i></i></a>
                  <a href="#" class="icon-enlarge2"><i></i></a>
                </nav>
              </footer>
            </section>
          </article>
          <article class="post">
            <img src="../assets/img/31.jpg" alt="" class="avator">
            <section class="content">
              <header>
                <span class="name">liliuchao</span>
                <span class="account">@llc</span>
                <span class="time">Yesterday</span>
              </header>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nostrum quos, doloremque voluptatem optio fugit autem reiciendis temporibus. </p>
              <footer>
                <nav>
                  <a href="#" class="icon-redo2"><i></i></a>
                  <a href="#" class="icon-star-full"><i></i></a>
                  <a href="#" class="icon-loop2"><i></i></a>
                  <a href="#" class="icon-flickr"><i></i></a>
                  <a href="#" class="icon-enlarge2"><i></i></a>
                </nav>
              </footer>
            </section>
          </article>
        </div>
      </div>
    </section>
    <aside class="right">
      <div class="trends">
        <h3>
          PHILIPPINES TRENDS
        </h3>
        <p>#DONTSTOPLYRICVIDEO</p>
        <p>#MLFTSHsComplicated</p>
        <p>#TangaLangMoments</p>
        <p>#a5WordsForYou</p>
        <p>#5SOSDONTSTOPLYRICVIDEO</p>
        <p>Happy Chieserifics Day</p>
        <p>Dr.Fluke</p>
        <p>JaDine For TBYD The Movie</p>
        <p>Galawang JaXel</p>
        <p>JulQuen For OBTCHTheMovie</p>
      </div>
      <div class="to-follow">
        <h3>WHO TO FOLLOW</h3>
        <a href="#">More</a>
        <div class="follow">
          <img src="../assets/img/2.jpg" alt="" class="avator">
          <div class="auth">
            <h3>Chris Spooner</h3>
            <p>Designer, Bloogger</p>
          </div>
          <div class="icon-plus"></div>
        </div>

        <div class="follow">
          <img src="../assets/img/3.jpg" alt="" class="avator">
          <div class="auth">
            <h3>HaraldurThorleifs</h3>
            <p>Creative Director</p>
          </div>
          <div class="icon-plus"></div>
        </div>

        <div class="follow">
          <img src="../assets/img/4.jpg" alt="" class="avator">
          <div class="auth">
            <h3>James Fletcher</h3>
            <p>Designer, Builderr</p>
          </div>
          <div class="icon-plus"></div>
        </div>

        <div class="follow">
          <img src="../assets/img/5.jpg" alt="" class="avator">
          <div class="auth">
            <h3>Nathan Powell</h3>
            <p>Designer Consultant</p>
          </div>
          <div class="icon-plus"></div>
        </div>

        <div class="follow">
          <img src="../assets/img/2.jpg" alt="" class="avator">
          <div class="auth">
            <h3>Nick Stater</h3>
            <p>Bloogger</p>
          </div>
          <div class="icon-plus"></div>
        </div>

      </div>
    </aside>
    <footer>
      <div class="copyright"></div>
    </footer>
  </div>
</template>

<script>
export default {
  name: 'HelloWorld',
  data () {
    return {
      msg: 'Welcome to Your Vue.js App'
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">


$post-bg-color:white;
$body-bg-color:#EFE8CB;
$gray-text-color:#d4d0c7;
$text-color:#fe4397;
$twitter-color:#84accb;
$text-p-color:white;
@mixin border-radius($borders:5px){
  border-radius:$borders;
}
@mixin clearfix(){
  clear:both;
}
$break-small:320px;
$break-large:1024px;
@mixin respond-to($media){
  @if $media==handhelds{

    @media only screen and (max-width:$break-small){
      @content;
    }
  }

    @else if $media==medium-screens{
      @media only screen and (min-width:$break-small+1) and(max-width:($break-large)-1){
        @content;
      }
    }
    @else if $media==wide-screens{
      @media only screen and (min-width:$break-small+1) and(min-width:$break-large){
        @content;
      }
    }
}
.hello{
  background-color:$body-bg-color;

  aside{
    background-color:#7fa9cc;
    width:20%;
    float:left;
    height:74em;
    position: relative;
    .profile{
      
      background-color:#7fa9cc;
      height:22em;
      position: relative;
      padding:3.5em 1em 3.5em 1em;

      text-align:center;
      .userimg1{
        
        width:5em;
        height:5em;
        
        
        margin-left:7em; 
        

        .img1{
          border-radius:100%;
          width:5em;

        }

      }

      h3{
        font-size:1.4em;
        font-weight:bold;
        color:$text-p-color;

      }
      p{
        color:#c3e1ee;
      }
      i,span{
        color:white;
      }

      input{
        font-size:1.4em;
        width:50%;
        height:1.5em;
        margin-top:1em;
        @include border-radius(2em);
        text-align:center;
        color:#d2eef7;
        font-weight:bold;
        background-color:#6b95b8;
        border:0;

      }
    }

    .gallery{
      clear:both;
      .imgwall{
        position: relative;
        width:100%;
        overflow:hidden;



        .imgs{
          width:33.33%;
          height:33.33%;
          margin:0;
          
          float:left;
          img{
            width:100%;
            height:100%;

          }
        }
      }
    }

    .activeties{
      padding:2em;
      h3{
        font-size:1.4em;
        color:#d6f9fd;
        
      }
      .linkto{
        padding:0.5em 0em;
        i{
          font-weight:bolder;
          color:#6a94b7;
        }
        span{
          display:inline-block;
          margin:0 0em;
          color:#6a94b7;
          font-weight:bold;
        }
        a{
          color:#e5f8fc;
        }
      }
    }
    
  }

  .contents{
    
    
    width:60%;
    
    float:left;
    background-color:$body-bg-color;
    .box{
      width:95%;
      margin:0 auto;

    .articles{
      width:100%;
      margin:auto;


      .post{
        position: relative;
        background-color:$post-bg-color;
        text-align:left;
        padding:2em 2em 0em 2em;
        border-bottom:1px solid $body-bg-color;

        .avator{
          width:3em;
          height:3em;
          @include border-radius(100%);
          position: absolute;
          top:2em;
          left:2em;

        }

        .content{
          margin-left:4em;
          width:92%;
          span{
            margin-right:1em;

            &.name{
              font-weight:bold;
            }

            &.account{
              font-weight:lighter;
              color:$gray-text-color;
            }

            &.time{
              color:$gray-text-color;
              float:right;
              margin-right:0;
            }

            &.icon-loop2{
              display:inline-block;
              margin-right:0.3em;
             color:#b5c990;
            }
          }
        }

      }
      p{

        color:#7b7b76;
        font-size:1.6em;
        margin:0em;
      }
    }

    .info{
      
      width:100%;
      height:7em;
      margin:2em auto;
      background:$post-bg-color;
      ul{
        padding:0px;
        list-style:none;
        margin:0 auto;
       
          li{
            
            width:25%;
            box-sizing:border-box;
            padding:0em 3em;
            border-bottom:3px solid transparent;
            transition:all .3s ease-in;
            float:left;
            text-align:center;
            cursor: pointer;
            @include respond-to(medium-screens);


            h4{
              text-transform:uppercase;
              color:$gray-text-color;

            }
            p{
              margin-top:1em;
              font-weight:bold;
            }
            &:hover{
              border-bottom:3px solid $twitter-color;
            }

          }
          @include clearfix;
      }
    }
  }
}
  .header{
    width:100%;
    background:$post-bg-color;
    border-bottom:2px solid #e2e2d8;
    nav{
      
      height:5em;
      

      ul{
        list-style-type: none;
        
        padding:0;

        

      }
      li{
        float:left;
        width:5em;
        height:5em;
        
        &:first-child{
          border-right:1px solid #ddd;
        }
        
        a{
          text-decoration:none;
          display:inline-block;
          width:3em;
          height:3em;
          
          margin:1em;
          border-radius:100%;
          border:1px solid #ccc;
          text-align:center;
          

          &.compose{
            background-color:#5577AA;

          }


          i{
            display:block;
            margin-top:0.55em;
            
            font-size:1.4em;
            color:#605f56;
            
          }
          .icon-quill{
            color:#fff;
          }



        }
      }
    }

    .bird{
      width:5em;
      height:5em;
      display:inline-block;
      background-color:white;
      margin-left:30em;
      text-align:center;
      .icon-twitter{
        display:inline-block;
        margin-top:0.3em;
        font-size:2.5em;
        color:#7aa5c1;
      }
    }
    input{
        float:right;
        height:2.5em;
        width:15em;
        margin-top:1.25em;
        margin-right:2em;
        border-radius:2em;
        border:1px solid #ccc;
        font-size:1em;
        color:#aaa;
        font-weight:bold;
      }
      .userimg{
        display:inline-block;
        width:3em;
        height:3em;
        
        
        margin-top:1em;
        margin-right:2em;
        float:right;
        img{
          border-radius:100%;
        }

      }

      .icon-search{
        display:inline-block;
        position:relative;
        left:9em;
        top:1.2em;
        font-size:1.6em;
        color:#aaa;
        float:right;
      }
  }
  section{
    margin-bottom:1em;

    p{
      line-height:1.4;
      font-weight:normal;
    }

    img{
      width:100%;
      margin-bottom:1em;

    }
  }


.right{
  float:left;
  width:20%;
  background-color:white;
  .trends{
    padding:1em 0;
    
    h3{
      margin-left:2em;
      font-weight:lighter;
      color:#808179;
    }
    p{
      margin:0.5em 2.2em;
      color:#98a6b2;
      font-weight:bold;

    }
  }
  .to-follow{

    
    padding:0em 1em;
    position: relative;
    h3{
      margin-left:1.5em;
      font-weight:lighter;
      display:inline-block;
      color:#808179;
    }
    a{
      text-decoration:none;
      float:right;
      font-size:1.2em;
      display:inline-block;
      margin-top:1em;
      color:#808179;
    }
    .follow{
      position: relative;
      height:4em;
      .avator{
        float:left;
            width:3em;
            height:3em;
            @include border-radius(100%);
            position: relative;
            top:0em;
            left:1.5em;

          }
          .auth{
            float:left;
            margin-left:2em;
            width:11.5em;
            h3,p{
              margin: 0 0.5em;
              color:#606157;
            }
            p{
              color:#c8c7bd;
            }
          }

          .icon-plus{
            width:0.8em;
            height:0.8em;
            font-weight:lighter;
            font-size:0.4em;
            color:#b0afa8;
            float:left;
            text-align:center;
            padding:0.5em;
            border:1px solid #f3f2e8;
          }
          
        }
  }
}
  footer{
    a{
      text-decoration:none;
      color:$gray-text-color;
      margin-right:1em;

      &:last-child{
        float:right;
        margin-right:0;
      }

      &:hover{
        color:$text-color;
      }


    }
  }

}
</style>
